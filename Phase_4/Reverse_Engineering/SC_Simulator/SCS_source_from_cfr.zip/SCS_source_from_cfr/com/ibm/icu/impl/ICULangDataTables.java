/*
 * Decompiled with CFR 0_110.
 */
package com.ibm.icu.impl;

import com.ibm.icu.impl.LocaleDisplayNamesImpl;
import com.ibm.icu.util.ULocale;

public class ICULangDataTables
extends LocaleDisplayNamesImpl.ICUDataTables {
    public ICULangDataTables() {
        super("com/ibm/icu/impl/data/icudt44b/lang");
    }
}

