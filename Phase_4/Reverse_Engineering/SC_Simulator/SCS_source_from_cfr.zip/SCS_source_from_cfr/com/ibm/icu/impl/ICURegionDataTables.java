/*
 * Decompiled with CFR 0_110.
 */
package com.ibm.icu.impl;

import com.ibm.icu.impl.LocaleDisplayNamesImpl;
import com.ibm.icu.util.ULocale;

public class ICURegionDataTables
extends LocaleDisplayNamesImpl.ICUDataTables {
    public ICURegionDataTables() {
        super("com/ibm/icu/impl/data/icudt44b/region");
    }
}

