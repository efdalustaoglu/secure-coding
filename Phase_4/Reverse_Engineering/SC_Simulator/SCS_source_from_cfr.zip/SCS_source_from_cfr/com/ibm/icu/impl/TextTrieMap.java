/*
 * Decompiled with CFR 0_110.
 */
package com.ibm.icu.impl;

import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.UTF16;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class TextTrieMap<V> {
    private TextTrieMap<V> root;
    boolean ignoreCase;

    public TextTrieMap(boolean ignoreCase) {
        this.root = new CharacterNode(0);
        this.ignoreCase = ignoreCase;
    }

    public synchronized void put(String text, V o) {
        Object node = this.root;
        for (int i = 0; i < text.length(); ++i) {
            int ch = UTF16.charAt(text, i);
            node = node.addChildNode(ch);
            if (UTF16.getCharCount(ch) != 2) continue;
            ++i;
        }
        node.addObject(o);
    }

    public Iterator<V> get(String text) {
        return this.get(text, 0);
    }

    public Iterator<V> get(String text, int start) {
        LongestMatchHandler handler = new LongestMatchHandler();
        this.find(text, start, handler);
        return handler.getMatches();
    }

    public void find(String text, ResultHandler<V> handler) {
        this.find(text, 0, handler);
    }

    public void find(String text, int start, ResultHandler<V> handler) {
        this.find(this.root, text, start, start, handler);
    }

    private synchronized void find(TextTrieMap<V> node, String text, int start, int index, ResultHandler<V> handler) {
        Iterator itr = node.iterator();
        if (itr != null && !handler.handlePrefixMatch(index - start, itr)) {
            return;
        }
        if (index < text.length()) {
            List childNodes = node.getChildNodes();
            if (childNodes == null) {
                return;
            }
            int ch = UTF16.charAt(text, index);
            int chLen = UTF16.getCharCount(ch);
            for (int i = 0; i < childNodes.size(); ++i) {
                CharacterNode child = (CharacterNode)((Object)childNodes.get(i));
                if (!this.compare(ch, child.getCharacter())) continue;
                this.find(child, text, start, index + chLen, handler);
                break;
            }
        }
    }

    private boolean compare(int ch1, int ch2) {
        if (ch1 == ch2) {
            return true;
        }
        if (this.ignoreCase) {
            if (UCharacter.toLowerCase(ch1) == UCharacter.toLowerCase(ch2)) {
                return true;
            }
            if (UCharacter.toUpperCase(ch1) == UCharacter.toUpperCase(ch2)) {
                return true;
            }
        }
        return false;
    }

    /*
     * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
     */
    private static class LongestMatchHandler<V>
    implements ResultHandler<V> {
        private Iterator<V> matches = null;
        private int length = 0;

        private LongestMatchHandler() {
        }

        @Override
        public boolean handlePrefixMatch(int matchLength, Iterator<V> values) {
            if (matchLength > this.length) {
                this.length = matchLength;
                this.matches = values;
            }
            return true;
        }

        public Iterator<V> getMatches() {
            return this.matches;
        }
    }

    public static interface ResultHandler<V> {
        public boolean handlePrefixMatch(int var1, Iterator<V> var2);
    }

    /*
     * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
     */
    private class CharacterNode {
        int character;
        List<TextTrieMap<V>> children;
        List<V> objlist;

        public CharacterNode(int ch) {
            this.character = ch;
        }

        public int getCharacter() {
            return this.character;
        }

        public void addObject(V obj) {
            if (this.objlist == null) {
                this.objlist = new LinkedList<V>();
            }
            this.objlist.add(obj);
        }

        public Iterator<V> iterator() {
            if (this.objlist == null) {
                return null;
            }
            return this.objlist.iterator();
        }

        public TextTrieMap<V> addChildNode(int ch) {
            if (this.children == null) {
                this.children = new ArrayList<TextTrieMap<V>>();
                CharacterNode newNode = new CharacterNode(ch);
                this.children.add((TextTrieMap<V>)((Object)newNode));
                return newNode;
            }
            CharacterNode node = null;
            for (int i = 0; i < this.children.size(); ++i) {
                CharacterNode cur = (CharacterNode)((Object)this.children.get(i));
                if (!TextTrieMap.this.compare(ch, cur.getCharacter())) continue;
                node = cur;
                break;
            }
            if (node == null) {
                node = new CharacterNode(ch);
                this.children.add((TextTrieMap<V>)((Object)node));
            }
            return node;
        }

        public List<TextTrieMap<V>> getChildNodes() {
            return this.children;
        }
    }

}

