/*
 * Decompiled with CFR 0_110.
 */
package com.ibm.icu.impl.data;

import java.util.ListResourceBundle;

public class BreakIteratorRules
extends ListResourceBundle {
    static final Object[][] contents = new Object[][]{{"BreakIteratorClasses", {"RuleBasedBreakIterator", "RuleBasedBreakIterator", "RuleBasedBreakIterator", "RuleBasedBreakIterator", "RuleBasedBreakIterator"}}};

    public Object[][] getContents() {
        return contents;
    }
}

