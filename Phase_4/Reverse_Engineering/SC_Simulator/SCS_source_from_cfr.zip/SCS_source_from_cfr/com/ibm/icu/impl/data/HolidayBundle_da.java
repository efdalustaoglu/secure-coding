/*
 * Decompiled with CFR 0_110.
 */
package com.ibm.icu.impl.data;

import java.util.ListResourceBundle;

public class HolidayBundle_da
extends ListResourceBundle {
    private static final Object[][] fContents = new Object[][]{{"Armistice Day", "v\u00e5benhvile"}, {"Ascension", "himmelfart"}, {"Boxing Day", "anden juledag"}, {"Christmas Eve", "juleaften"}, {"Easter", "p\u00e5ske"}, {"Epiphany", "helligtrekongersdag"}, {"Good Friday", "langfredag"}, {"Halloween", "allehelgensaften"}, {"Maundy Thursday", "sk\u00e6rtorsdag"}, {"Palm Sunday", "palmes\u00f8ndag"}, {"Pentecost", "pinse"}, {"Shrove Tuesday", "hvidetirsdag"}};

    public synchronized Object[][] getContents() {
        return fContents;
    }
}

