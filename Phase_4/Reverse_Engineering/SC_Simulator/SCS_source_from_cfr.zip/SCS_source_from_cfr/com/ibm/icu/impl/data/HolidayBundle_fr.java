/*
 * Decompiled with CFR 0_110.
 */
package com.ibm.icu.impl.data;

import java.util.ListResourceBundle;

public class HolidayBundle_fr
extends ListResourceBundle {
    private static final Object[][] fContents = new Object[][]{{"All Saints' Day", "Toussaint"}, {"Armistice Day", "Jour de l'Armistice"}, {"Ascension", "Ascension"}, {"Bastille Day", "F\u00eate de la Bastille"}, {"Benito Ju\u00e1rez Day", "F\u00eate de Benito Ju\u00e1rez"}, {"Boxing Day", "Lendemain de No\u00ebl"}, {"Christmas Eve", "Veille de No\u00ebl"}, {"Christmas", "No\u00ebl"}, {"Easter Monday", "P\u00e2ques lundi"}, {"Easter Sunday", "P\u00e2ques"}, {"Epiphany", "l'\u00c9piphanie"}, {"Flag Day", "F\u00eate du Drapeau"}, {"Good Friday", "Vendredi Saint"}, {"Halloween", "Veille de la Toussaint"}, {"All Saints' Day", "Toussaint"}, {"Independence Day", "F\u00eate Ind\u00e9pendance"}, {"Maundy Thursday", "Jeudi Saint"}, {"Mother's Day", "F\u00eate des m\u00e8res"}, {"National Day", "F\u00eate Nationale"}, {"New Year's Day", "Jour de l'an"}, {"Palm Sunday", "les Rameaux"}, {"Pentecost", "Pentec\u00f4te"}, {"Shrove Tuesday", "Mardi Gras"}, {"St. Stephen's Day", "Saint-\u00c9tienne"}, {"Victoria Day", "F\u00eate de la Victoria"}, {"Victory Day", "F\u00eate de la Victoire"}};

    public synchronized Object[][] getContents() {
        return fContents;
    }
}

