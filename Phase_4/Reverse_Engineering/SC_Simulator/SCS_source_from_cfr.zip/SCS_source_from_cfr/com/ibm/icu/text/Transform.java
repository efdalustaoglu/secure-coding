/*
 * Decompiled with CFR 0_110.
 */
package com.ibm.icu.text;

public interface Transform<S, D> {
    public D transform(S var1);
}

