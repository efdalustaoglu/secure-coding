/*
 * Decompiled with CFR 0_110.
 */
package com.ibm.icu.text;

abstract class TransformTransliterator {
    TransformTransliterator() {
    }
}

