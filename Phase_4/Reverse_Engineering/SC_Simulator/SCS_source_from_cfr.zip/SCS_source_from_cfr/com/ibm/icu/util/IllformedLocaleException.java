/*
 * Decompiled with CFR 0_110.
 */
package com.ibm.icu.util;

public class IllformedLocaleException
extends IllegalArgumentException {
    private static final long serialVersionUID = 1;
    private int _errIdx = -1;

    public IllformedLocaleException(String msg) {
        this(msg, -1);
    }

    public IllformedLocaleException(String msg, int errIdx) {
        super(msg + (errIdx == -1 ? "" : new StringBuilder().append(" [at index ").append(errIdx).append("]").toString()));
        this._errIdx = errIdx;
    }

    public int getErrorIndex() {
        return this._errIdx;
    }
}

