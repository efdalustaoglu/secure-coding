/*
 * Decompiled with CFR 0_110.
 */
package com.ibm.icu.util;

public abstract class MeasureUnit {
    protected MeasureUnit() {
    }
}

