/*
 * Decompiled with CFR 0_110.
 */
package com.ibm.icu.util;

public class UResourceTypeMismatchException
extends RuntimeException {
    static final long serialVersionUID = 1286569061095434541L;

    public UResourceTypeMismatchException(String msg) {
        super(msg);
    }
}

