/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

import org.eclipse.core.commands.Command;
import org.eclipse.core.commands.common.AbstractBitSetEvent;
import org.eclipse.core.commands.common.AbstractNamedHandleEvent;

public final class CommandEvent
extends AbstractNamedHandleEvent {
    private static final int CHANGED_CATEGORY = 4;
    private static final int CHANGED_HANDLED = 8;
    private static final int CHANGED_PARAMETERS = 16;
    private static final int CHANGED_RETURN_TYPE = 32;
    private static final int CHANGED_HELP_CONTEXT_ID = 64;
    private static final int CHANGED_ENABLED = 128;
    private final Command command;

    public CommandEvent(Command command, boolean categoryChanged, boolean definedChanged, boolean descriptionChanged, boolean handledChanged, boolean nameChanged, boolean parametersChanged) {
        this(command, categoryChanged, definedChanged, descriptionChanged, handledChanged, nameChanged, parametersChanged, false);
    }

    public CommandEvent(Command command, boolean categoryChanged, boolean definedChanged, boolean descriptionChanged, boolean handledChanged, boolean nameChanged, boolean parametersChanged, boolean returnTypeChanged) {
        this(command, categoryChanged, definedChanged, descriptionChanged, handledChanged, nameChanged, parametersChanged, returnTypeChanged, false);
    }

    public CommandEvent(Command command, boolean categoryChanged, boolean definedChanged, boolean descriptionChanged, boolean handledChanged, boolean nameChanged, boolean parametersChanged, boolean returnTypeChanged, boolean helpContextIdChanged) {
        this(command, categoryChanged, definedChanged, descriptionChanged, handledChanged, nameChanged, parametersChanged, returnTypeChanged, helpContextIdChanged, false);
    }

    public CommandEvent(Command command, boolean categoryChanged, boolean definedChanged, boolean descriptionChanged, boolean handledChanged, boolean nameChanged, boolean parametersChanged, boolean returnTypeChanged, boolean helpContextIdChanged, boolean enabledChanged) {
        super(definedChanged, descriptionChanged, nameChanged);
        if (command == null) {
            throw new NullPointerException();
        }
        this.command = command;
        if (categoryChanged) {
            this.changedValues |= 4;
        }
        if (handledChanged) {
            this.changedValues |= 8;
        }
        if (parametersChanged) {
            this.changedValues |= 16;
        }
        if (returnTypeChanged) {
            this.changedValues |= 32;
        }
        if (helpContextIdChanged) {
            this.changedValues |= 64;
        }
        if (enabledChanged) {
            this.changedValues |= 128;
        }
    }

    public final Command getCommand() {
        return this.command;
    }

    public final boolean isCategoryChanged() {
        if ((this.changedValues & 4) != 0) {
            return true;
        }
        return false;
    }

    public final boolean isHandledChanged() {
        if ((this.changedValues & 8) != 0) {
            return true;
        }
        return false;
    }

    public final boolean isHelpContextIdChanged() {
        if ((this.changedValues & 64) != 0) {
            return true;
        }
        return false;
    }

    public final boolean isParametersChanged() {
        if ((this.changedValues & 16) != 0) {
            return true;
        }
        return false;
    }

    public final boolean isReturnTypeChanged() {
        if ((this.changedValues & 32) != 0) {
            return true;
        }
        return false;
    }

    public final boolean isEnabledChanged() {
        if ((this.changedValues & 128) != 0) {
            return true;
        }
        return false;
    }
}

