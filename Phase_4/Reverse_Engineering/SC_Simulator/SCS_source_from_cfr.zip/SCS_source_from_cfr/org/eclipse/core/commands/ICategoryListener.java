/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

import org.eclipse.core.commands.CategoryEvent;

public interface ICategoryListener {
    public void categoryChanged(CategoryEvent var1);
}

