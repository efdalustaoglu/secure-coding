/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

import org.eclipse.core.commands.CommandEvent;

public interface ICommandListener {
    public void commandChanged(CommandEvent var1);
}

