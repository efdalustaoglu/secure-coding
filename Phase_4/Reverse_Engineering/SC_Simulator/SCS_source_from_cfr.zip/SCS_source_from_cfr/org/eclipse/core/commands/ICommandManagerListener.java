/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

import org.eclipse.core.commands.CommandManagerEvent;

public interface ICommandManagerListener {
    public void commandManagerChanged(CommandManagerEvent var1);
}

