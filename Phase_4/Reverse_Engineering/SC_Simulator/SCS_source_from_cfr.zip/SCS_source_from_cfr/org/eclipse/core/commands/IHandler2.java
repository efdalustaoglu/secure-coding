/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

import org.eclipse.core.commands.IHandler;

public interface IHandler2
extends IHandler {
    public void setEnabled(Object var1);
}

