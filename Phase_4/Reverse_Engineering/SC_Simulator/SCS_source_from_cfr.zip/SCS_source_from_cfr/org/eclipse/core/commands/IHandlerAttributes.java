/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

public interface IHandlerAttributes {
    public static final String ATTRIBUTE_HANDLED = "handled";
}

