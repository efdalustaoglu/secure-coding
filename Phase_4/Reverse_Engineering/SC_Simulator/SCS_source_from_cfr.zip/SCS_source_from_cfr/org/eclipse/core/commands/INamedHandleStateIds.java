/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

public interface INamedHandleStateIds {
    public static final String DESCRIPTION = "DESCRIPTION";
    public static final String NAME = "NAME";
}

