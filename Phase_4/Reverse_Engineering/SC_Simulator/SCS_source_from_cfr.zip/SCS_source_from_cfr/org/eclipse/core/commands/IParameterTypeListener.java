/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

import org.eclipse.core.commands.ParameterTypeEvent;

public interface IParameterTypeListener {
    public void parameterTypeChanged(ParameterTypeEvent var1);
}

