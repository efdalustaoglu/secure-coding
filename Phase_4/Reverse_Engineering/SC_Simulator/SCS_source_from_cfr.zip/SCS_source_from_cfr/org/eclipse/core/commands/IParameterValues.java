/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

import java.util.Map;

public interface IParameterValues {
    public Map getParameterValues();
}

