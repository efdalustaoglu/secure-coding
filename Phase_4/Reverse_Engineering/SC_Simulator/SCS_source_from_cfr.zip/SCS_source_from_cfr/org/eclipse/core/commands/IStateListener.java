/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

import org.eclipse.core.commands.State;

public interface IStateListener {
    public void handleStateChange(State var1, Object var2);
}

