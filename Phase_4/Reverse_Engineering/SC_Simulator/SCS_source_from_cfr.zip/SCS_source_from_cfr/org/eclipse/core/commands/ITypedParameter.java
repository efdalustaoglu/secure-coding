/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

import org.eclipse.core.commands.ParameterType;

public interface ITypedParameter {
    public ParameterType getParameterType();
}

