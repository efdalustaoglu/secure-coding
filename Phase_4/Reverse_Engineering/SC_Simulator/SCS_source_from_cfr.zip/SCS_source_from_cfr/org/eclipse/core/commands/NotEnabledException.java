/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

import org.eclipse.core.commands.common.CommandException;

public final class NotEnabledException
extends CommandException {
    private static final long serialVersionUID = 3257572788998124596L;

    public NotEnabledException(String s) {
        super(s);
    }
}

