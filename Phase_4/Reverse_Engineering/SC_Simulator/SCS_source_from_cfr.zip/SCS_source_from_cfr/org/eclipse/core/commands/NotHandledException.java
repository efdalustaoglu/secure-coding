/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

import org.eclipse.core.commands.common.CommandException;

public final class NotHandledException
extends CommandException {
    private static final long serialVersionUID = 3256446914827726904L;

    public NotHandledException(String s) {
        super(s);
    }
}

