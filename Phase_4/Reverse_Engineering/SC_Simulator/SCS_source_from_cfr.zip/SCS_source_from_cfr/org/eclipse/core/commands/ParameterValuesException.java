/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands;

import org.eclipse.core.commands.common.CommandException;

public final class ParameterValuesException
extends CommandException {
    private static final long serialVersionUID = 3618976793520845623L;

    public ParameterValuesException(String message, Throwable cause) {
        super(message, cause);
    }
}

