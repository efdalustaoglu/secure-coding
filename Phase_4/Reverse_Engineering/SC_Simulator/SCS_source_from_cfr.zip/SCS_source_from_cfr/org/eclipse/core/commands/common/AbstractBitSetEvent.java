/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands.common;

public abstract class AbstractBitSetEvent {
    protected int changedValues = 0;
}

