/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands.common;

import org.eclipse.core.commands.common.AbstractBitSetEvent;
import org.eclipse.core.commands.common.AbstractHandleObjectEvent;

public abstract class AbstractNamedHandleEvent
extends AbstractHandleObjectEvent {
    protected static final int CHANGED_DESCRIPTION = 2;
    protected static final int CHANGED_NAME = 2;
    protected static final int LAST_USED_BIT = 2;

    protected AbstractNamedHandleEvent(boolean definedChanged, boolean descriptionChanged, boolean nameChanged) {
        super(definedChanged);
        if (descriptionChanged) {
            this.changedValues |= 2;
        }
        if (nameChanged) {
            this.changedValues |= 2;
        }
    }

    public final boolean isDescriptionChanged() {
        if ((this.changedValues & 2) != 0) {
            return true;
        }
        return false;
    }

    public final boolean isNameChanged() {
        if ((this.changedValues & 2) != 0) {
            return true;
        }
        return false;
    }
}

