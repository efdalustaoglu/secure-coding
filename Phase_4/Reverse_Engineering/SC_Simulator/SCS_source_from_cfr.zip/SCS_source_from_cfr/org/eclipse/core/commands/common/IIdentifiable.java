/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands.common;

public interface IIdentifiable {
    public String getId();
}

