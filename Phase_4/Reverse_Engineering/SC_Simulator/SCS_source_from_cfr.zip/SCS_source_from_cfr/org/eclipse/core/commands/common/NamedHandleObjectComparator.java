/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands.common;

import java.util.Comparator;
import org.eclipse.core.commands.common.NamedHandleObject;
import org.eclipse.core.commands.common.NotDefinedException;
import org.eclipse.core.internal.commands.util.Util;

public class NamedHandleObjectComparator
implements Comparator {
    public final int compare(Object left, Object right) {
        String bName;
        String aName;
        NamedHandleObject b;
        NamedHandleObject a = (NamedHandleObject)left;
        b = (NamedHandleObject)right;
        aName = null;
        try {
            aName = a.getName();
        }
        catch (NotDefinedException v0) {}
        bName = null;
        try {
            bName = b.getName();
        }
        catch (NotDefinedException v1) {}
        return Util.compare((Comparable)((Object)aName), (Comparable)((Object)bName));
    }
}

