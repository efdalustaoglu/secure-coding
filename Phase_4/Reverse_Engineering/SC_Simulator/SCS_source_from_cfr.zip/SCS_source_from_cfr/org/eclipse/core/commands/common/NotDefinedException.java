/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands.common;

import org.eclipse.core.commands.common.CommandException;

public final class NotDefinedException
extends CommandException {
    private static final long serialVersionUID = 3257572788998124596L;

    public NotDefinedException(String s) {
        super(s);
    }
}

