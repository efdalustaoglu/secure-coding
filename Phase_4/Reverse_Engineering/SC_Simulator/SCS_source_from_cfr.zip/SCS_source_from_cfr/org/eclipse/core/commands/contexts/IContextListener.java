/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands.contexts;

import org.eclipse.core.commands.contexts.ContextEvent;

public interface IContextListener {
    public void contextChanged(ContextEvent var1);
}

