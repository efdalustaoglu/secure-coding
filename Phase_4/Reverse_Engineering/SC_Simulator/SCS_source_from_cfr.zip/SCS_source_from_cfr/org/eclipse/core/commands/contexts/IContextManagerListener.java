/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands.contexts;

import org.eclipse.core.commands.contexts.ContextManagerEvent;

public interface IContextManagerListener {
    public void contextManagerChanged(ContextManagerEvent var1);
}

