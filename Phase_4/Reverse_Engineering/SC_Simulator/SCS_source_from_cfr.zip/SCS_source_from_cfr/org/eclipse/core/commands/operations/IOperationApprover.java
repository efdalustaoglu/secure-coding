/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands.operations;

import org.eclipse.core.commands.operations.IOperationHistory;
import org.eclipse.core.commands.operations.IUndoableOperation;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IStatus;

public interface IOperationApprover {
    public IStatus proceedRedoing(IUndoableOperation var1, IOperationHistory var2, IAdaptable var3);

    public IStatus proceedUndoing(IUndoableOperation var1, IOperationHistory var2, IAdaptable var3);
}

