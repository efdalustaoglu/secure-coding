/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands.operations;

public interface IUndoContext {
    public String getLabel();

    public boolean matches(IUndoContext var1);
}

