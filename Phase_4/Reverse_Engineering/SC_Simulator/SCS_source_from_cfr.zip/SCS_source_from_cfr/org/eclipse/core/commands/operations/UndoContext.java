/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands.operations;

import org.eclipse.core.commands.operations.IUndoContext;

public class UndoContext
implements IUndoContext {
    public String getLabel() {
        return "";
    }

    public boolean matches(IUndoContext context) {
        if (context == this) {
            return true;
        }
        return false;
    }
}

