/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.commands.util;

import java.io.PrintStream;

public final class Tracing {
    public static final String SEPARATOR = " >>> ";

    public static final void printTrace(String component, String message) {
        StringBuffer buffer = new StringBuffer();
        if (component != null) {
            buffer.append(component);
        }
        if (component != null && message != null) {
            buffer.append(" >>> ");
        }
        if (message != null) {
            buffer.append(message);
        }
        System.out.println(buffer.toString());
    }

    private Tracing() {
    }
}

