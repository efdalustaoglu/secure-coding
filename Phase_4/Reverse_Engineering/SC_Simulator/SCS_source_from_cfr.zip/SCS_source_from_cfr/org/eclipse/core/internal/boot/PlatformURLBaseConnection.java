/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.internal.boot;

import java.io.IOException;
import java.net.URL;
import org.eclipse.core.internal.boot.PlatformURLConnection;
import org.eclipse.core.internal.boot.PlatformURLHandler;
import org.eclipse.core.internal.runtime.CommonMessages;
import org.eclipse.osgi.util.NLS;

public class PlatformURLBaseConnection
extends PlatformURLConnection {
    public static final String PLATFORM = "base";
    public static final String PLATFORM_URL_STRING = "platform:/base/";
    private static URL installURL;
    static /* synthetic */ Class class$0;

    public PlatformURLBaseConnection(URL url) {
        super(url);
    }

    protected boolean allowCaching() {
        return true;
    }

    protected URL resolve() throws IOException {
        String spec = this.url.getFile().trim();
        if (spec.startsWith("/")) {
            spec = spec.substring(1);
        }
        if (!spec.startsWith("base/")) {
            String message = NLS.bind(CommonMessages.url_badVariant, this.url);
            throw new IOException(message);
        }
        return spec.length() == "base".length() + 1 ? installURL : new URL(installURL, spec.substring("base".length() + 1));
    }

    public static void startup(URL url) {
        Class class_;
        if (installURL != null) {
            return;
        }
        installURL = url;
        class_ = class$0;
        if (class_ == null) {
            try {
                class_ = PlatformURLBaseConnection.class$0 = Class.forName("org.eclipse.core.internal.boot.PlatformURLBaseConnection");
            }
            catch (ClassNotFoundException v1) {
                throw new NoClassDefFoundError(v1.getMessage());
            }
        }
        PlatformURLHandler.register("base", class_);
    }
}

