/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  org.eclipse.core.internal.preferences.exchange.IProductPreferencesService
 */
package org.eclipse.core.internal.preferences.legacy;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;
import org.eclipse.core.internal.preferences.exchange.IProductPreferencesService;
import org.eclipse.core.internal.runtime.InternalPlatform;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProduct;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.osgi.framework.Bundle;

public class ProductPreferencesService
implements IProductPreferencesService {
    private static final IPath NL_DIR = new Path("$nl$");
    public static final String PRODUCT_KEY = "preferenceCustomization";
    private static final String LEGACY_PRODUCT_CUSTOMIZATION_FILENAME = "plugin_customization.ini";
    private static final String PROPERTIES_FILE_EXTENSION = "properties";
    private boolean initialized = false;
    private String customizationValue = null;
    private Bundle customizationBundle = null;
    private String productID = null;

    private void initValues() {
        if (this.initialized) {
            return;
        }
        this.initialized = true;
        IProduct product = Platform.getProduct();
        if (product == null) {
            if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES) {
                InternalPlatform.message("Product not available to set product default preference overrides.");
            }
            return;
        }
        this.productID = product.getId();
        if (this.productID == null) {
            if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES) {
                InternalPlatform.message("Product ID not available to apply product-level preference defaults.");
            }
            return;
        }
        this.customizationBundle = product.getDefiningBundle();
        if (this.customizationBundle == null) {
            if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES) {
                InternalPlatform.message("Bundle not available to apply product-level preference defaults for product id: " + this.productID);
            }
            return;
        }
        this.customizationValue = product.getProperty("preferenceCustomization");
        if (this.customizationValue == null) {
            if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES) {
                InternalPlatform.message("Product : " + this.productID + " does not define preference customization file. Using legacy file: plugin_customization.ini");
            }
            this.customizationValue = "plugin_customization.ini";
        }
    }

    public Properties getProductCustomization() {
        this.initValues();
        URL url = null;
        if (this.customizationValue != null) {
            try {
                url = new URL(this.customizationValue);
            }
            catch (MalformedURLException v0) {
                url = FileLocator.find(this.customizationBundle, new Path(this.customizationValue), null);
            }
        }
        if (url == null && InternalPlatform.DEBUG_PLUGIN_PREFERENCES) {
            InternalPlatform.message("Product preference customization file: " + this.customizationValue + " not found for bundle: " + this.productID);
        }
        return this.loadProperties(url);
    }

    public Properties getProductTranslation() {
        this.initValues();
        URL transURL = null;
        if (this.customizationValue != null) {
            transURL = FileLocator.find(this.customizationBundle, NL_DIR.append(this.customizationValue).removeFileExtension().addFileExtension("properties"), null);
        }
        if (transURL == null && InternalPlatform.DEBUG_PLUGIN_PREFERENCES) {
            InternalPlatform.message("No preference translations found for product/file: " + this.customizationBundle.getSymbolicName() + '/' + this.customizationValue);
        }
        return this.loadProperties(transURL);
    }

    private Properties loadProperties(URL url) {
        Properties result;
        block16 : {
            InputStream input;
            result = new Properties();
            if (url == null) {
                return result;
            }
            input = null;
            try {
                try {
                    input = url.openStream();
                    result.load(input);
                }
                catch (IOException e) {
                    if (InternalPlatform.DEBUG_PLUGIN_PREFERENCES) {
                        InternalPlatform.message("Problem opening stream to preference customization file: " + url);
                        e.printStackTrace();
                    }
                    if (input != null) {
                        try {
                            input.close();
                        }
                        catch (IOException v0) {}
                    }
                    break block16;
                }
            }
            catch (Throwable var5_5) {
                if (input != null) {
                    try {
                        input.close();
                    }
                    catch (IOException v1) {}
                }
                throw var5_5;
            }
            if (input != null) {
                try {
                    input.close();
                }
                catch (IOException v2) {}
            }
        }
        return result;
    }
}

