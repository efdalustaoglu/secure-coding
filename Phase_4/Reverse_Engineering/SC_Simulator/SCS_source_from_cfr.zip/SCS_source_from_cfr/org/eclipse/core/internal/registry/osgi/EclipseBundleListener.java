/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.internal.registry.osgi;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import org.eclipse.core.internal.registry.ExtensionRegistry;
import org.eclipse.core.internal.registry.RegistryMessages;
import org.eclipse.core.internal.registry.osgi.OSGIUtils;
import org.eclipse.core.internal.registry.osgi.RegistryStrategyOSGI;
import org.eclipse.core.internal.runtime.ResourceTranslator;
import org.eclipse.core.internal.runtime.RuntimeLog;
import org.eclipse.core.runtime.ContributorFactoryOSGi;
import org.eclipse.core.runtime.IContributor;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.ManifestElement;
import org.eclipse.osgi.util.NLS;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleEvent;
import org.osgi.framework.BundleException;
import org.osgi.framework.SynchronousBundleListener;

public class EclipseBundleListener
implements SynchronousBundleListener {
    private static final String PLUGIN_MANIFEST = "plugin.xml";
    private static final String FRAGMENT_MANIFEST = "fragment.xml";
    private ExtensionRegistry registry;
    private RegistryStrategyOSGI strategy;
    private Object token;
    private HashMap dynamicAddStateStamps = new HashMap();
    private long[] currentStateStamp = new long[1];

    public EclipseBundleListener(ExtensionRegistry registry, Object key, RegistryStrategyOSGI strategy) {
        this.registry = registry;
        this.token = key;
        this.strategy = strategy;
    }

    public void bundleChanged(BundleEvent event) {
        Bundle bundle = event.getBundle();
        switch (event.getType()) {
            case 32: {
                long[] arrl = this.currentStateStamp;
                synchronized (arrl) {
                    long newStateStamp = this.registry.computeState();
                    if (this.currentStateStamp[0] != newStateStamp) {
                        this.currentStateStamp[0] = newStateStamp;
                        this.dynamicAddStateStamps.clear();
                    }
                }
                this.addBundle(bundle, true);
                break;
            }
            case 64: {
                this.removeBundle(bundle);
            }
        }
    }

    public void processBundles(Bundle[] bundles) {
        int i = 0;
        while (i < bundles.length) {
            if (this.isBundleResolved(bundles[i])) {
                this.addBundle(bundles[i], false);
            } else {
                this.removeBundle(bundles[i]);
            }
            ++i;
        }
    }

    private boolean isBundleResolved(Bundle bundle) {
        if ((bundle.getState() & 60) != 0) {
            return true;
        }
        return false;
    }

    private void removeBundle(Bundle bundle) {
        URL pluginManifest;
        long timestamp = 0;
        if (this.strategy.checkContributionsTimestamp() && (pluginManifest = EclipseBundleListener.getExtensionURL(bundle, false)) != null) {
            timestamp = this.strategy.getExtendedTimestamp(bundle, pluginManifest);
        }
        this.registry.remove(Long.toString(bundle.getBundleId()), timestamp);
    }

    public static URL getExtensionURL(Bundle bundle, boolean report) {
        if (bundle.getBundleId() == 0) {
            return null;
        }
        if (bundle.getSymbolicName() == null) {
            return null;
        }
        boolean isFragment = OSGIUtils.getDefault().isFragment(bundle);
        String manifestName = isFragment ? "fragment.xml" : "plugin.xml";
        URL extensionURL = bundle.getEntry(manifestName);
        if (extensionURL == null) {
            return null;
        }
        if (!EclipseBundleListener.isSingleton(bundle)) {
            if (report && !EclipseBundleListener.isGeneratedManifest(bundle)) {
                String message = NLS.bind(RegistryMessages.parse_nonSingleton, bundle.getSymbolicName());
                RuntimeLog.log(new Status(2, "org.eclipse.equinox.registry", 0, message, null));
            }
            return null;
        }
        if (!isFragment) {
            return extensionURL;
        }
        Bundle[] hosts = OSGIUtils.getDefault().getHosts(bundle);
        if (hosts == null) {
            return null;
        }
        if (EclipseBundleListener.isSingleton(hosts[0])) {
            return extensionURL;
        }
        if (report) {
            String message = NLS.bind(RegistryMessages.parse_nonSingletonFragment, bundle.getSymbolicName(), hosts[0].getSymbolicName());
            RuntimeLog.log(new Status(2, "org.eclipse.equinox.registry", 0, message, null));
        }
        return null;
    }

    private static boolean isGeneratedManifest(Bundle bundle) {
        if (bundle.getHeaders("").get("Generated-from") != null) {
            return true;
        }
        return false;
    }

    private void addBundle(Bundle bundle, boolean checkNLSFragments) {
        ResourceBundle translationBundle;
        IContributor contributor;
        BufferedInputStream is;
        URL pluginManifest;
        if (checkNLSFragments) {
            this.checkForNLSFragment(bundle);
        }
        if (this.registry.hasContributor(contributor = ContributorFactoryOSGi.createContributor(bundle))) {
            return;
        }
        pluginManifest = EclipseBundleListener.getExtensionURL(bundle, true);
        if (pluginManifest == null) {
            return;
        }
        try {
            is = new BufferedInputStream(pluginManifest.openStream());
        }
        catch (IOException v0) {
            is = null;
        }
        if (is == null) {
            return;
        }
        translationBundle = null;
        try {
            translationBundle = ResourceTranslator.getResourceBundle(bundle);
        }
        catch (MissingResourceException v1) {}
        long timestamp = 0;
        if (this.strategy.checkContributionsTimestamp()) {
            timestamp = this.strategy.getExtendedTimestamp(bundle, pluginManifest);
        }
        this.registry.addContribution(is, contributor, true, pluginManifest.getPath(), translationBundle, this.token, timestamp);
    }

    private void checkForNLSFragment(Bundle bundle) {
        if (!OSGIUtils.getDefault().isFragment(bundle)) {
            long[] arrl = this.currentStateStamp;
            synchronized (arrl) {
                this.dynamicAddStateStamps.put(Long.toString(bundle.getBundleId()), new Long(this.currentStateStamp[0]));
            }
            return;
        }
        Bundle[] hosts = OSGIUtils.getDefault().getHosts(bundle);
        if (hosts == null) {
            return;
        }
        int i = 0;
        while (i < hosts.length) {
            this.checkForNLSFiles(hosts[i], bundle);
            ++i;
        }
    }

    private void checkForNLSFiles(Bundle host, Bundle fragment) {
        int i;
        String hostID = Long.toString(host.getBundleId());
        long[] arrl = this.currentStateStamp;
        synchronized (arrl) {
            Long hostStateStamp = (Long)this.dynamicAddStateStamps.get(hostID);
            if (hostStateStamp != null && this.currentStateStamp[0] == hostStateStamp) {
                return;
            }
        }
        Bundle[] fragments = OSGIUtils.getDefault().getFragments(host);
        boolean refresh = false;
        if (this.hasNLSFilesFor(host, fragment)) {
            refresh = true;
        } else {
            i = 0;
            while (i < fragments.length && !refresh) {
                if (!fragment.equals(fragments[i]) && this.hasNLSFilesFor(fragments[i], fragment)) {
                    refresh = true;
                }
                ++i;
            }
        }
        if (refresh) {
            this.removeBundle(host);
            this.addBundle(host, false);
            i = 0;
            while (i < fragments.length) {
                if (!fragment.equals(fragments[i])) {
                    this.removeBundle(fragments[i]);
                    this.addBundle(fragments[i], false);
                }
                ++i;
            }
            long[] i2 = this.currentStateStamp;
            synchronized (i2) {
                this.dynamicAddStateStamps.put(hostID, new Long(this.currentStateStamp[0]));
            }
        }
    }

    private boolean hasNLSFilesFor(Bundle target, Bundle fragment) {
        URL baseNLS;
        String filePattern;
        if (!this.registry.hasContributor(Long.toString(target.getBundleId()))) {
            return false;
        }
        Dictionary<String, String> targetHeaders = target.getHeaders("");
        String localization = targetHeaders.get("Bundle-Localization");
        if (localization == null) {
            localization = "OSGI-INF/l10n/bundle";
        }
        if ((baseNLS = target.getEntry(String.valueOf(localization) + ".properties")) == null) {
            return false;
        }
        int lastSlash = localization.lastIndexOf(47);
        if (lastSlash == localization.length() - 1) {
            return false;
        }
        String baseDir = lastSlash < 0 ? "" : localization.substring(0, lastSlash);
        Enumeration<URL> nlsFiles = fragment.findEntries(baseDir, filePattern = String.valueOf(lastSlash < 0 ? localization : localization.substring(lastSlash + 1)) + "_*.properties", false);
        if (nlsFiles != null) {
            return true;
        }
        return false;
    }

    private static boolean isSingleton(Bundle bundle) {
        Dictionary<String, String> allHeaders = bundle.getHeaders("");
        String symbolicNameHeader = allHeaders.get("Bundle-SymbolicName");
        try {
            ManifestElement[] symbolicNameElements;
            if (symbolicNameHeader != null && (symbolicNameElements = ManifestElement.parseHeader("Bundle-SymbolicName", symbolicNameHeader)).length > 0) {
                String singleton = symbolicNameElements[0].getDirective("singleton");
                if (singleton == null) {
                    singleton = symbolicNameElements[0].getAttribute("singleton");
                }
                if (!"true".equalsIgnoreCase(singleton)) {
                    String manifestVersion = allHeaders.get("Bundle-ManifestVersion");
                    if (manifestVersion == null && OSGIUtils.getDefault().getBundle(symbolicNameElements[0].getValue()) == bundle) {
                        return true;
                    }
                    return false;
                }
            }
        }
        catch (BundleException v0) {}
        return true;
    }
}

