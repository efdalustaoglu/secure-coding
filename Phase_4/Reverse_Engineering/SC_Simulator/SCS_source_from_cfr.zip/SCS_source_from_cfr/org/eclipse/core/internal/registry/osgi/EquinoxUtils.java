/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.internal.registry.osgi;

import java.util.Dictionary;
import org.eclipse.core.internal.registry.osgi.OSGIUtils;
import org.eclipse.core.internal.registry.osgi.RegistryCommandProvider;
import org.eclipse.osgi.service.environment.EnvironmentInfo;
import org.eclipse.osgi.service.resolver.PlatformAdmin;
import org.eclipse.osgi.service.resolver.State;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;

public class EquinoxUtils {
    public static String[] getCommandLine(BundleContext context, ServiceReference ref) {
        if (ref == null) {
            return null;
        }
        try {
            EnvironmentInfo environmentInfo = (EnvironmentInfo)context.getService(ref);
            String[] arrstring = environmentInfo == null ? null : environmentInfo.getNonFrameworkArgs();
            return arrstring;
        }
        finally {
            context.ungetService(ref);
        }
    }

    public static long getContainerTimestamp(BundleContext context, ServiceReference ref) {
        if (ref == null) {
            return -1;
        }
        try {
            PlatformAdmin admin = (PlatformAdmin)context.getService(ref);
            long l = admin == null ? -1 : admin.getState(false).getTimeStamp();
            return l;
        }
        finally {
            context.ungetService(ref);
        }
    }

    public static ServiceRegistration registerCommandProvider(BundleContext context) {
        try {
            return context.registerService("org.eclipse.osgi.framework.console.CommandProvider", (Object)new RegistryCommandProvider(), null);
        }
        catch (NoClassDefFoundError v0) {
            return null;
        }
    }

    public static boolean isActive(String bundleId) {
        Bundle bundle;
        block4 : {
            try {
                bundle = OSGIUtils.getDefault().getBundle(bundleId);
                if (bundle != null) break block4;
                return false;
            }
            catch (NoClassDefFoundError v0) {
                return true;
            }
        }
        if (bundle.getState() == 32) {
            return true;
        }
        return false;
    }
}

