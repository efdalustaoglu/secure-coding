/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.internal.registry.osgi;

import org.eclipse.core.internal.registry.RegistryMessages;
import org.eclipse.core.internal.registry.osgi.Activator;
import org.eclipse.core.internal.runtime.RuntimeLog;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.service.datalocation.Location;
import org.eclipse.osgi.service.debug.DebugOptions;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.service.packageadmin.PackageAdmin;
import org.osgi.util.tracker.ServiceTracker;
import org.osgi.util.tracker.ServiceTrackerCustomizer;

public class OSGIUtils {
    private ServiceTracker debugTracker = null;
    private ServiceTracker bundleTracker = null;
    private ServiceTracker configurationLocationTracker = null;
    public static final String PROP_CONFIG_AREA = "osgi.configuration.area";
    public static final String PROP_INSTANCE_AREA = "osgi.instance.area";
    private static final OSGIUtils singleton = new OSGIUtils();
    static /* synthetic */ Class class$0;
    static /* synthetic */ Class class$1;

    public static OSGIUtils getDefault() {
        return singleton;
    }

    private OSGIUtils() {
        this.initServices();
    }

    private void initServices() {
        Filter filter;
        BundleContext context;
        Class class_;
        Class class_2;
        context = Activator.getContext();
        if (context == null) {
            RuntimeLog.log(new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.bundle_not_activated, null));
            return;
        }
        class_2 = class$0;
        if (class_2 == null) {
            try {
                class_2 = OSGIUtils.class$0 = Class.forName("org.eclipse.osgi.service.debug.DebugOptions");
            }
            catch (ClassNotFoundException v1) {
                throw new NoClassDefFoundError(v1.getMessage());
            }
        }
        this.debugTracker = new ServiceTracker(context, class_2.getName(), null);
        this.debugTracker.open();
        class_ = class$1;
        if (class_ == null) {
            try {
                class_ = OSGIUtils.class$1 = Class.forName("org.osgi.service.packageadmin.PackageAdmin");
            }
            catch (ClassNotFoundException v3) {
                throw new NoClassDefFoundError(v3.getMessage());
            }
        }
        this.bundleTracker = new ServiceTracker(context, class_.getName(), null);
        this.bundleTracker.open();
        filter = null;
        try {
            filter = context.createFilter("(&(objectClass=org.eclipse.osgi.service.datalocation.Location)(type=osgi.configuration.area))");
        }
        catch (InvalidSyntaxException v4) {}
        this.configurationLocationTracker = new ServiceTracker(context, filter, null);
        this.configurationLocationTracker.open();
    }

    void closeServices() {
        if (this.debugTracker != null) {
            this.debugTracker.close();
            this.debugTracker = null;
        }
        if (this.bundleTracker != null) {
            this.bundleTracker.close();
            this.bundleTracker = null;
        }
        if (this.configurationLocationTracker != null) {
            this.configurationLocationTracker.close();
            this.configurationLocationTracker = null;
        }
    }

    public boolean getBooleanDebugOption(String option, boolean defaultValue) {
        String value;
        if (this.debugTracker == null) {
            RuntimeLog.log(new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.bundle_not_activated, null));
            return defaultValue;
        }
        DebugOptions options = (DebugOptions)this.debugTracker.getService();
        if (options != null && (value = options.getOption(option)) != null) {
            return value.equalsIgnoreCase("true");
        }
        return defaultValue;
    }

    public PackageAdmin getPackageAdmin() {
        if (this.bundleTracker == null) {
            RuntimeLog.log(new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.bundle_not_activated, null));
            return null;
        }
        return (PackageAdmin)this.bundleTracker.getService();
    }

    public Bundle getBundle(String bundleName) {
        PackageAdmin packageAdmin = this.getPackageAdmin();
        if (packageAdmin == null) {
            return null;
        }
        Bundle[] bundles = packageAdmin.getBundles(bundleName, null);
        if (bundles == null) {
            return null;
        }
        int i = 0;
        while (i < bundles.length) {
            if ((bundles[i].getState() & 3) == 0) {
                return bundles[i];
            }
            ++i;
        }
        return null;
    }

    public Bundle[] getFragments(Bundle bundle) {
        PackageAdmin packageAdmin = this.getPackageAdmin();
        if (packageAdmin == null) {
            return null;
        }
        return packageAdmin.getFragments(bundle);
    }

    public boolean isFragment(Bundle bundle) {
        PackageAdmin packageAdmin = this.getPackageAdmin();
        if (packageAdmin == null) {
            return false;
        }
        if ((packageAdmin.getBundleType(bundle) & 1) > 0) {
            return true;
        }
        return false;
    }

    public Bundle[] getHosts(Bundle bundle) {
        PackageAdmin packageAdmin = this.getPackageAdmin();
        if (packageAdmin == null) {
            return null;
        }
        return packageAdmin.getHosts(bundle);
    }

    public Location getConfigurationLocation() {
        if (this.configurationLocationTracker == null) {
            return null;
        }
        return (Location)this.configurationLocationTracker.getService();
    }
}

