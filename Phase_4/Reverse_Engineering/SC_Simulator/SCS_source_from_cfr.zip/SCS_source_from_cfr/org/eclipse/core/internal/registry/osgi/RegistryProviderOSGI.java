/*
 * Decompiled with CFR 0_110.
 */
package org.eclipse.core.internal.registry.osgi;

import org.eclipse.core.internal.registry.RegistryMessages;
import org.eclipse.core.internal.registry.osgi.Activator;
import org.eclipse.core.internal.runtime.RuntimeLog;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.spi.IRegistryProvider;
import org.osgi.framework.BundleContext;
import org.osgi.util.tracker.ServiceTracker;
import org.osgi.util.tracker.ServiceTrackerCustomizer;

public final class RegistryProviderOSGI
implements IRegistryProvider {
    private ServiceTracker registryTracker = null;
    static /* synthetic */ Class class$0;

    public IExtensionRegistry getRegistry() {
        if (this.registryTracker == null) {
            Class class_;
            BundleContext context;
            context = Activator.getContext();
            if (context == null) {
                RuntimeLog.log(new Status(4, "org.eclipse.equinox.registry", 0, RegistryMessages.bundle_not_activated, null));
                return null;
            }
            class_ = class$0;
            if (class_ == null) {
                try {
                    class_ = RegistryProviderOSGI.class$0 = Class.forName("org.eclipse.core.runtime.IExtensionRegistry");
                }
                catch (ClassNotFoundException v1) {
                    throw new NoClassDefFoundError(v1.getMessage());
                }
            }
            this.registryTracker = new ServiceTracker(context, class_.getName(), null);
            this.registryTracker.open();
        }
        return (IExtensionRegistry)this.registryTracker.getService();
    }

    public void release() {
        if (this.registryTracker != null) {
            this.registryTracker.close();
            this.registryTracker = null;
        }
    }
}

