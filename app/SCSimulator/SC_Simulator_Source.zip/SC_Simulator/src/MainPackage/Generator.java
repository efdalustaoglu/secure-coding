package MainPackage;


import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


// a3   cc   a2   b2   aa   1e   3b   5b   3b   5a   ad   99   a8   52   90   74
// 10100011   11001100 10100010 10110010   10101010 00011110 00111011   01011011 00111011 01011010   10101101 10011001 10101000   01010010 10010000 01110100
//10 100011  110011 001010 001010 110010  101010 100001 111000 111011  010110 110011 101101 011010  101011 011001 100110 101000  010100 101001 000001 110100
//                                              |<--------------------------------------------------------------------------------------------------------->|

//Zahl: 52, 1, 41, 20, 40, 38, 25, 43, 26, 45, 51, 22, 59, 56, 33


public class Generator {

	private static String generateTANfromHash(byte[] hash){
		String alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz01";
		byte output[] = new byte[15];
		
		if(hash.length != 16){
			return null;
		}
		
		output[0] = (byte) (hash[15] & 63);
		output[1] = (byte) ((hash[15] & 192) >> 6 | (hash[14] & 15) << 2);
		output[2] = (byte) ((hash[14] & 240) >> 4 | (hash[13] & 3) << 4);
		output[3] = (byte) ((hash[13] & 252) >> 2);
		output[4] = (byte) (hash[12] & 63);
		output[5] = (byte) ((hash[12] & 192) >> 6 | (hash[11] & 15) << 2);
		output[6] = (byte) ((hash[11] & 240) >> 4 | (hash[10] & 3) << 4);
		output[7] = (byte) ((hash[10] & 252) >> 2);
		output[8] = (byte) (hash[9] & 63);
		output[9] = (byte) ((hash[9] & 192) >> 6 | (hash[8] & 15) << 2);
		output[10] = (byte) ((hash[8] & 240) >> 4 | (hash[7] & 3) << 4);
		output[11] = (byte) ((hash[7] & 252) >> 2);
		output[12] = (byte) (hash[6] & 63);
		output[13] = (byte) ((hash[6] & 192) >> 6 | (hash[5] & 15) << 2);
		output[14] = (byte) ((hash[5] & 240) >> 4 | (hash[4] & 3) << 4);
		//System.out.println("Zahl: " + output[0] + ", " + output[1] + ", " + output[2] + ", " + output[3] + ", " + output[4] + ", " + output[5] + ", " + output[6] + ", " + output[7] + ", " + output[8] + ", " + output[9] + ", " + output[10] + ", " + output[11] + ", " + output[12] + ", " + output[13] + ", " + output[14]);
		
		String tan = new String();
		for(int i=0; i<15; i++){
			//System.out.println();
			tan = tan + String.valueOf(alphabet.charAt(output[i]));
		}
		
		//System.out.println("Tan: " + tan);
		return tan;
	}
	
	
	
	
	public static String generateOTP(int passNr, String pin){
		if(passNr < 1 || pin == null){
			return null;
		}
		byte[] seed = pin.getBytes(StandardCharsets.UTF_8);
		byte[] hash;
		String tan = "";
		MessageDigest md;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			return null;
		}
		
		for(int i=0; i<passNr; i++){
			hash = md.digest(seed);
			tan = generateTANfromHash(hash);
			seed = tan.getBytes(StandardCharsets.UTF_8);
		}
		
		
		//String password = new String(tan, StandardCharsets.UTF_8);
		System.out.println(tan);
		return tan;
		
	}
	
	
}
