package MainPackage;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.prefs.Preferences;

import javax.swing.JRadioButton;

public class InitializeRequest extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private int state = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			InitializeRequest dialog = new InitializeRequest();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public InitializeRequest() {
		setResizable(false);
		setBounds(100, 100, 430, 280);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		setLocationRelativeTo(null);
		
		JLabel lblWelcome = new JLabel("Welcome to the Smart Card Simulator!");
		lblWelcome.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblWelcome.setBounds(28, 24, 343, 37);
		contentPanel.add(lblWelcome);
		
		JLabel lblStartInfo = new JLabel("<html>Before you can use the Smart Card Simulator to generate <br>TANs for your bank account you have to complete a few configuration steps.<br><br>Please click on \"Start\" to start the configuration.</html>");
		lblStartInfo.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblStartInfo.setVerticalAlignment(SwingConstants.TOP);
		lblStartInfo.setBounds(28, 79, 363, 103);
		contentPanel.add(lblStartInfo);
		
		JLabel lbl1Info = new JLabel("<html>Where did you get this Smart Card Simulator?</html>");
		lbl1Info.setVerticalAlignment(SwingConstants.TOP);
		lbl1Info.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lbl1Info.setBounds(28, 34, 363, 37);
		lbl1Info.setVisible(false);
		contentPanel.add(lbl1Info);
		
		ButtonGroup origin = new ButtonGroup();
		
		JRadioButton rdbOption1 = new JRadioButton("I just downloaded it from the banking website.");
		rdbOption1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		rdbOption1.setBounds(28, 62, 363, 44);
		rdbOption1.setVisible(false);
		rdbOption1.doClick();
		origin.add(rdbOption1);
		contentPanel.add(rdbOption1);
		
		JRadioButton rdbOption2 = new JRadioButton("<html>I moved it here from another directory, but havn't <br>used it before.</html>");
		rdbOption2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		rdbOption2.setBounds(28, 106, 363, 37);
		rdbOption2.setVisible(false);
		origin.add(rdbOption2);
		contentPanel.add(rdbOption2);
		
		JRadioButton rdbOption3 = new JRadioButton("<html>I moved it here from another directory and have <br>used it before.</html>");
		rdbOption3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		rdbOption3.setBounds(28, 145, 363, 37);
		rdbOption3.setVisible(false);
		origin.add(rdbOption3);
		contentPanel.add(rdbOption3);
		
		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);
		
		
		JButton cancelButton = new JButton("Cancel");
		

		JButton okButton = new JButton("Start");
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!rdbOption1.isSelected() && !rdbOption2.isSelected()  && !rdbOption3.isSelected()){
					return;
				}
				if(state == 0){
					lblWelcome.setVisible(false);
					lblStartInfo.setVisible(false);
					okButton.setText("Next");
					lbl1Info.setVisible(true);
					rdbOption1.setVisible(true);
					rdbOption2.setVisible(true);
					rdbOption3.setVisible(true);
					state = 1;
				}
				else if(state == 1){
					if(rdbOption1.isSelected() || rdbOption2.isSelected()){
						rdbOption3.setVisible(false);
						lbl1Info.setText("Where would you like to save the program settings?");
						rdbOption1.setText("<html>In a configuration file located in the same directory <br>as the Smart Card Simulator.</html>");
						rdbOption2.setText("In the user environment (e.g. Registry in Windows).");
						rdbOption1.doClick();
						state = 2;
					}
					else if(rdbOption3.isSelected()){
						lbl1Info.setText("No settings from previous runs were found on this system.");
						lblStartInfo.setText("<html>If you used a configuration file before, please copy it to the current directory. Otherwise please download the Smart Card Simulator again. Thank you.");
						lblStartInfo.setVisible(true);
						cancelButton.setText("Finish");
						okButton.setVisible(false);
						rdbOption1.setVisible(false);
						rdbOption2.setVisible(false);
						rdbOption3.setVisible(false);
						state = 3;
					}
				}
				else if(state == 2){
					if(rdbOption1.isSelected()){
						if(createNewConfigFile() == false){
							JOptionPane.showMessageDialog(null, "There was an error while creating a new config file!", "Error", JOptionPane.ERROR_MESSAGE);
							System.exit(0);
						}
					}
					else if(rdbOption2.isSelected()){
						createNewRegEntry();
					}
					lblStartInfo.setText("The Smart Card Simulator was configured successfully!");
					lblStartInfo.setVisible(true);
					cancelButton.setText("Finish");
					lbl1Info.setVisible(false);
					okButton.setVisible(false);
					rdbOption1.setVisible(false);
					rdbOption2.setVisible(false);
					rdbOption3.setVisible(false);
					state = 4;
				}
				
			}
		});
		
		
		cancelButton.setActionCommand("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(state < 4){
					System.exit(0);
					return;
				}
				setVisible(false);
				dispose();
				return;
			}
		});
		buttonPane.add(cancelButton);

	}
	
	private boolean createNewConfigFile(){
		File f = new File("sc_simulator.conf");
		if(!f.exists() || !f.isFile()){
			try {
				f.createNewFile();
			} catch (IOException e) {
				return false;
			}
		}
		RandomAccessFile file;
		try {
			file = new RandomAccessFile(f, "rw");
			file.writeBytes("PIN_NR: 0");
			file.close();
			return true;
		} catch (IOException e) {
			return false;
		}
	}
	
	private void createNewRegEntry(){
		Preferences.userRoot().node("/com/secure-coding/sc-simulator").put("PIN_NR", "0");
	}
	
	
}
