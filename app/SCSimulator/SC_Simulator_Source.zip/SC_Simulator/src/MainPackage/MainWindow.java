package MainPackage;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;
import java.awt.Window.Type;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;

import javax.swing.JButton;
import javax.swing.JSeparator;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JDesktopPane;
import javax.swing.JFileChooser;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JTextField;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class MainWindow {

	private JFrame frmSmartCardSimulator;
	
	private static String PIN = "000000000000000";
	private static int PIN_NR = -1;
	private static int MAX_TAN_COUNT = 1000;
	private JTextField txtTAN;
	private JTextField txtSender;
	private JTextField txtRecipient;
	private JTextField txtAmount;
	private JTextField txtTan;
	private JTextField txtPath;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow window = new MainWindow();
					window.frmSmartCardSimulator.setLocationRelativeTo(null);
					window.frmSmartCardSimulator.setEnabled(false);
					window.frmSmartCardSimulator.setFocusable(false);
					window.frmSmartCardSimulator.setVisible(true);
					
					PinRequest pinRequest = new PinRequest();
					pinRequest.setModal(true);
					pinRequest.setVisible(true);
					
					PIN = "000000000" + pinRequest.getPin();
					if(PIN.equals("000000000xxxxxx")){
						System.exit(0);
					}
					window.frmSmartCardSimulator.setEnabled(true);
					window.frmSmartCardSimulator.setFocusable(true);
					
					
					if((PIN_NR = getPinNr(false)) < 0){
						if((PIN_NR = getPinNr(true)) < 0){
							InitializeRequest initRequest = new InitializeRequest();
							initRequest.setModal(true);
							initRequest.setVisible(true);
							
							if((PIN_NR = getPinNr(false)) < 0){
								if((PIN_NR = getPinNr(true)) < 0){
									JOptionPane.showMessageDialog(null, "The configuration of the Smart Card Simulator failed!", "Error", JOptionPane.ERROR_MESSAGE);
									System.exit(0);
								}
							}
						}
					}
					
					if(PIN_NR >= MAX_TAN_COUNT){
						JOptionPane.showMessageDialog(null, "The validity of this Smart Card Simulator has expired. Please download a new simulator from your banking website.", "Information", JOptionPane.INFORMATION_MESSAGE);
						System.exit(0);
					}
					
					
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frmSmartCardSimulator = new JFrame();
		frmSmartCardSimulator.setTitle("Smart Card Simulator");
		frmSmartCardSimulator.setResizable(false);
		frmSmartCardSimulator.setBounds(100, 100, 460, 200);
		frmSmartCardSimulator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSmartCardSimulator.getContentPane().setLayout(null);
		
		JLabel lblGenerateNewTan = new JLabel("Generate new TAN:");
		lblGenerateNewTan.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblGenerateNewTan.setBounds(12, 13, 152, 23);
		frmSmartCardSimulator.getContentPane().add(lblGenerateNewTan);
		
		
		txtTAN = new JTextField();
		txtTAN.setBackground(Color.WHITE);
		txtTAN.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtTAN.setBounds(123, 54, 146, 22);
		frmSmartCardSimulator.getContentPane().add(txtTAN);
		txtTAN.setColumns(10);
		
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 103, 454, 15);
		frmSmartCardSimulator.getContentPane().add(separator);
		
		JLabel lblSender = new JLabel("Sender's account:");
		lblSender.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblSender.setBounds(22, 170, 142, 23);
		frmSmartCardSimulator.getContentPane().add(lblSender);
		
		JLabel lblRecipient = new JLabel("Recipient's account:");
		lblRecipient.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblRecipient.setBounds(22, 200, 142, 23);
		frmSmartCardSimulator.getContentPane().add(lblRecipient);
		
		JLabel lblAmount = new JLabel("Amount:");
		lblAmount.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblAmount.setBounds(22, 230, 142, 23);
		frmSmartCardSimulator.getContentPane().add(lblAmount);
		
		JLabel lblTan = new JLabel("TAN:");
		lblTan.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblTan.setBounds(22, 260, 142, 23);
		frmSmartCardSimulator.getContentPane().add(lblTan);
		
		txtSender = new JTextField();
		txtSender.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtSender.setBounds(165, 171, 224, 22);
		frmSmartCardSimulator.getContentPane().add(txtSender);
		txtSender.setColumns(10);
		
		txtRecipient = new JTextField();
		txtRecipient.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtRecipient.setColumns(10);
		txtRecipient.setBounds(165, 201, 224, 22);
		frmSmartCardSimulator.getContentPane().add(txtRecipient);
		
		txtAmount = new JTextField();
		txtAmount.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtAmount.setColumns(10);
		txtAmount.setBounds(165, 231, 224, 22);
		frmSmartCardSimulator.getContentPane().add(txtAmount);
		
		txtTan = new JTextField();
		txtTan.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtTan.setColumns(10);
		txtTan.setBounds(165, 261, 224, 22);
		frmSmartCardSimulator.getContentPane().add(txtTan);
		
		JLabel lblOutputFile = new JLabel("Output file:");
		lblOutputFile.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblOutputFile.setBounds(22, 303, 142, 23);
		frmSmartCardSimulator.getContentPane().add(lblOutputFile);
		
		txtPath = new JTextField();
		txtPath.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtPath.setColumns(10);
		txtPath.setBounds(165, 303, 224, 22);
		frmSmartCardSimulator.getContentPane().add(txtPath);
		
		JButton btOutputFile = new JButton("...");
		btOutputFile.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btOutputFile.setBounds(401, 303, 32, 25);
		btOutputFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser fileChooser = new JFileChooser();
				FileNameExtensionFilter filter = new FileNameExtensionFilter("Text file", "txt", "*");
				fileChooser.setFileFilter(filter);
				if (fileChooser.showSaveDialog(frmSmartCardSimulator) == JFileChooser.APPROVE_OPTION) {
					txtPath.setText(fileChooser.getSelectedFile().getAbsolutePath());
				}
			}
		});
		frmSmartCardSimulator.getContentPane().add(btOutputFile);
		
		
		
		
		JButton btTransactionFile = new JButton("Transaction file >>");
		btTransactionFile.setEnabled(false);
		btTransactionFile.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btTransactionFile.setBounds(12, 117, 152, 31);
		btTransactionFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(btTransactionFile.getText().equals("Transaction file >>")){
					btTransactionFile.setText("Transaction file <<");
					txtSender.setText("");
					txtRecipient.setText("");
					txtAmount.setText("");
					frmSmartCardSimulator.setBounds(100, 100, 460, 420);
					frmSmartCardSimulator.setLocationRelativeTo(null);
				}
				else{
					btTransactionFile.setText("Transaction file >>");
					frmSmartCardSimulator.setBounds(100, 100, 460, 200);
					frmSmartCardSimulator.setLocationRelativeTo(null);
				}
			}
		});
		frmSmartCardSimulator.getContentPane().add(btTransactionFile);
		
		
		JButton btCopy = new JButton("Copy to Clipboard");
		btCopy.setEnabled(false);
		btCopy.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btCopy.setBounds(281, 49, 152, 31);
		btCopy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StringSelection selection = new StringSelection(txtTAN.getText());
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				clipboard.setContents(selection, selection);
			}
		});
		frmSmartCardSimulator.getContentPane().add(btCopy);
		
		
		JButton btGenerate = new JButton("Generate");
		btGenerate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(MAX_TAN_COUNT - PIN_NR < 1){
					JOptionPane.showMessageDialog(null, "The validity of this Smart Card Simulator has expired. Please download a new simulator from your banking website.", "Information", JOptionPane.INFORMATION_MESSAGE);
					return;
				}
				String tan = Generator.generateOTP(MAX_TAN_COUNT - PIN_NR, PIN);
				if(tan == null){
					return;
				}
				
				txtTAN.setText(tan);
				PIN_NR++;
				if(!setPinNr(PIN_NR)){
					JOptionPane.showMessageDialog(null, "The settings could not be updated!", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				btCopy.setEnabled(true);
				txtTan.setText(tan);
				btTransactionFile.setEnabled(true);
				
			}
		});
		btGenerate.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btGenerate.setBounds(12, 49, 97, 31);
		frmSmartCardSimulator.getContentPane().add(btGenerate);
		
		
		JButton btExit = new JButton("Exit");
		btExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btExit.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btExit.setBounds(336, 117, 97, 31);
		frmSmartCardSimulator.getContentPane().add(btExit);
		
		
		
		
		JButton btClear = new JButton("Clear");
		btClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtSender.setText("");
				txtRecipient.setText("");
				txtAmount.setText("");
			}
		});
		btClear.setBounds(114, 348, 97, 25);
		frmSmartCardSimulator.getContentPane().add(btClear);
		
		
		JButton btAdd = new JButton("Add to file");
		btAdd.setBounds(223, 348, 97, 25);
		btAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(txtSender.getText().length() == 0){
					JOptionPane.showMessageDialog(null, "Please enter your account number in the field 'Sender's account'!", "Invalid input", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(txtRecipient.getText().length() == 0){
					JOptionPane.showMessageDialog(null, "Please enter a valid account number for the recipient!", "Invalid input", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(txtTan.getText().length() != 15){
					JOptionPane.showMessageDialog(null, "Please enter a valid TAN!", "Invalid input", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(txtPath.getText().length() == 0){
					JOptionPane.showMessageDialog(null, "Please enter a valid path for the transaction file!", "Invalid input", JOptionPane.WARNING_MESSAGE);
					return;
				}
				
				try{
					int testAmount = Integer.parseInt(txtAmount.getText());
					if(testAmount <= 0){
						JOptionPane.showMessageDialog(null, "Please enter a valid amount to be transfered!", "Invalid input", JOptionPane.WARNING_MESSAGE);
						return;
					}
				}
				catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "Please enter a valid amount to be transfered!", "Invalid input", JOptionPane.WARNING_MESSAGE);
					return;
				}
				
				
				File file = new File(txtPath.getText());
				if(!file.exists()){
					try {
						file.createNewFile();
					} catch (IOException e) {
						JOptionPane.showMessageDialog(null, "The file could not be created!", "Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
				}
				if(file.exists() && file.isFile()){
					try {
						RandomAccessFile raf  = new RandomAccessFile(file, "rw");
						if(!file.canWrite()){
							file.setWritable(true);
						}
						if(file.length() > 0){
							raf.seek(file.length());
							raf.write((new String(System.lineSeparator() + System.lineSeparator() + "##################################################" + System.lineSeparator() + System.lineSeparator())).getBytes());
						}
						raf.seek(file.length());
						raf.write((new String("SENDER_ACCOUNT:\t\t" + txtSender.getText() + System.lineSeparator())).getBytes());
						raf.write((new String("RECIPIENT_ACCOUNT:\t" + txtRecipient.getText() + System.lineSeparator())).getBytes());
						raf.write((new String("TAN:\t\t\t" + txtTan.getText() + System.lineSeparator())).getBytes());
						raf.write((new String("AMOUNT:\t\t\t" + txtAmount.getText())).getBytes());
						raf.close();
						System.out.println(file.getAbsolutePath());
						
					} catch (IOException e) {
						JOptionPane.showMessageDialog(null, "The selected file could not be accessed!", "Error", JOptionPane.ERROR_MESSAGE);
					}
					
					txtRecipient.setText("");
					txtAmount.setText("");
					
				}
				else{
					JOptionPane.showMessageDialog(null, "The selected file could not be accessed!", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		frmSmartCardSimulator.getContentPane().add(btAdd);
		
		
		
		
	}
	
	
	
	private static int getPinNr(boolean readFromFile){
		if(readFromFile == false){
			try {
				if(Preferences.userRoot().nodeExists("/com/secure-coding/sc-simulator")){
					return Preferences.userRoot().node("/com/secure-coding/sc-simulator").getInt("PIN_NR", -1);
				}
				else{
					return -1;
				}
			} catch (BackingStoreException e) {
				return -1;
			}
		}
		else{
			File f = new File("sc_simulator.conf");
			if(f.exists() && f.isFile()){
				RandomAccessFile file;
				try {
					file = new RandomAccessFile(f, "r");
					String content = file.readLine();
					file.close();
					if(content != null && content.startsWith("PIN_NR:")){
						return Integer.parseInt(content.substring(7).trim());
					}
					return -1;
				} catch (IOException | NumberFormatException e) {
					return -1;
				}
			}
			else{
				return -1;
			}
		}

	}
	
	
	private boolean setPinNr(int pinNr){
		if(pinNr < 0 || pinNr > 1000){
			return false;
		}
		File f = new File("sc_simulator.conf");
		if(f.exists() && f.isFile()){
			try{
				RandomAccessFile file;
				file = new RandomAccessFile(f, "rw");
				file.writeBytes("PIN_NR: " + pinNr);
				file.close();
				return true;
			}
			catch (IOException e) {
				return false;
			}
		}
		else{
			try {
				if(Preferences.userRoot().nodeExists("/com/secure-coding/sc-simulator")){
					Preferences.userRoot().node("/com/secure-coding/sc-simulator").put("PIN_NR", Integer.toString(pinNr));
					return true;
				}
				else{
					return false;
				}
			} catch (BackingStoreException e) {
				return false;
			}
		}
			
	}
	
	
}
