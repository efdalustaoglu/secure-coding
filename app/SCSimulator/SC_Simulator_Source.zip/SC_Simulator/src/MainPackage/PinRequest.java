package MainPackage;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPasswordField;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PinRequest extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JPasswordField passwordField;
	private JLabel lblError;
	private JButton okButton;
	private JButton cancelButton;
	
	private String PIN = "xxxxxx";

	/**
	 * Create the dialog.
	 */
	public PinRequest() {
		setResizable(false);
		setAlwaysOnTop(true);
		setBounds(100, 100, 285, 185);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		setLocationRelativeTo(null);
		
		JLabel lblPleaseEnterYour = new JLabel("Please enter your PIN:");
		lblPleaseEnterYour.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPleaseEnterYour.setBounds(32, 31, 201, 16);
		contentPanel.add(lblPleaseEnterYour);
		
		lblError = new JLabel("");
		lblError.setForeground(Color.RED);
		lblError.setBounds(32, 85, 211, 16);
		contentPanel.add(lblError);
		
		passwordField = new JPasswordField();
		DocumentListener docListener = new DocumentListener() {
			public void changedUpdate(DocumentEvent e) {
					isInputValid();
				}
				public void removeUpdate(DocumentEvent e) {
					isInputValid();
				}
				public void insertUpdate(DocumentEvent e) {
					isInputValid();
				}
			};
			
		passwordField.getDocument().addDocumentListener(docListener);
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 18));
		passwordField.setBounds(32, 60, 211, 22);
		contentPanel.add(passwordField);

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		okButton = new JButton("OK");
		okButton.setEnabled(false);
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				dispose();
			}
		});

		cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				closeApp();
			}
		});
		cancelButton.setActionCommand("Cancel");
		buttonPane.add(cancelButton);
		
	}
	
	
	
	private boolean isInputValid(){
		String input;
		input = new String(passwordField.getPassword());
		if(input.length() < 6){
			lblError.setText("The PIN is too short");
			okButton.setEnabled(false);
			return false;
		}
		else if(input.length() > 6){
			lblError.setText("The PIN is too long");
			okButton.setEnabled(false);
			return false;
		}
		else{
			lblError.setText("");
			for(int i=0; i<input.length(); i++){
				if(input.charAt(i) < 48 || input.charAt(i) > 57){
					lblError.setText("The PIN must only contain digits");
					okButton.setEnabled(false);
					return false;
				}
			}
		}
		
		PIN = input;
		okButton.setEnabled(true);
		return true;
	}
	
	
	public void closeApp(){
		System.exit(0);
	}
	
	
	private void setPin(String pin){
		this.PIN = pin;
	}
	
	public String getPin(){
		return PIN;
	}
	
	
	
}
